from pylatex import Document, Figure, MiniPage, Tabularx, MultiColumn, TextColor
from pylatex.section import Section, Subsection,\
    Paragraph, Subsubsection, Subparagraph
from pylatex.utils import NoEscape, rm_temp_dir, bold
from pylatex.basic import NewLine, NewPage, Package, LargeText, \
    LineBreak, MediumText
from pylatex.headfoot import PageStyle, simple_page_number, Foot, Head, Command
from pylatex.position import VerticalSpace, FlushLeft, FlushRight, Center


class LatexDocument:

    def __init__(self, font_size=12, geom_options=None):
        if geom_options is None:
            geom_options = {"tmargin": "20mm", "lmargin": "30mm",
                            "bmargin": "20mm", "rmargin": "10mm"}
        self.doc = Document('doc_1', geometry_options=geom_options)
        self.doc.documentclass = Command('documentclass',
                                         options=[f'{font_size}pt'],
                                         arguments=['article'])
        self.doc.packages.add(Package('babel', options=['english', 'russian']))
        # self.doc.packages.add(Package('fancyhdr'))
        self.doc.packages.add(Package('tocvsec2'))
        self.doc.packages.append(Package("graphicx"))
        self.doc.packages.append(Package("parskip"))

        # self.doc.append(NoEscape(r'\settocdepth{subparagraph}'))
        # self.doc.append(NoEscape(r'\setcounter{page}{1}'))

# ЗАГОЛОВКИ
    def center_page_title(self, info):
        po = {'R': FlushRight(), 'L': FlushLeft(), 'C': Center()}
        with self.doc.create(po[info['pos']]) as center:
            center.append(VerticalSpace(NoEscape(r'\fill')))
            for i in info['text']:
                center.append(Section(title=i, numbering=False))
            center.append(VerticalSpace(NoEscape(r'\fill')))

    def make_title(self, info):
        po = {'R': FlushRight(), 'L': FlushLeft(), 'C': Center()}
        with self.doc.create(po[info['pos']]) as el:
            el.append(Section(info['text'].upper(), numbering=info['numbering']))

    def make_subtitle(self, info):
        po = {'R': FlushRight(), 'L': FlushLeft(), 'C': Center()}
        with self.doc.create(po[info['pos']]) as el:
            el.append(Subsection(info['text'].upper(), numbering=info['numbering']))

    def make_subsubtitle(self, info):
        po = {'R': FlushRight(), 'L': FlushLeft(), 'C': Center()}
        with self.doc.create(po[info['pos']]) as el:
            el.append(Subsubsection(info['text'].upper(), numbering=info['numbering']))

    def add_paragraph(self, info):
        po = {'R': FlushRight(), 'L': FlushLeft(), 'C': Center()}
        with self.doc.create(po[info['pos']]) as el:
            el.append(Paragraph(info['text'].upper(), numbering=info['numbering']))

    def add_subparagraph(self, info):
        po = {'R': FlushRight(), 'L': FlushLeft(), 'C': Center()}
        with self.doc.create(po[info['pos']]) as el:
            el.append(Subparagraph(info['text'].upper(), numbering=info['numbering']))

# РАЗНЫЕ ТЕСТА
    def make_table(self):
        with self.doc.create(Center()) as el:
            el.append(NoEscape(r'\tableofcontents'))

    # def make_head_or_foot(self, text, pos):
    #     with self.doc.create(self.pos[pos]) as el:
    #         el.append(text)

    def make_numeration_style(self, info):
        numbers_style = PageStyle('numerationtype')
        places = {'H': Head, 'F': Foot}
        with numbers_style.create(places[info['num_place']](info['pos'])) as el:
            el.append(NoEscape(info['num_type']))
            self.doc.preamble.append(numbers_style)
            self.doc.change_document_style('numerationtype')

    def add_text(self, info):
        skip_len = r'\hskip ' + str(info['hor_skip']) + 'em'
        with self.doc.create(FlushLeft()) as el:
            el.append(NoEscape(skip_len))
            el.append(info['text'])
            el.append(NoEscape(r'\newline'))

# ОСТАЛЬНОЕ
    def add_image(self, info):
        with self.doc.create(Figure(position="h")) as image:
            image.add_image(f"photos/{info['pic_name']}.png")
            # image.add_image(f"{pic_name}.jpg", width="400px")
            image.add_caption("Example Image")

    def add_number_of_pages(self, info):
        po = {'R': FlushRight(), 'L': FlushLeft(), 'C': Center()}
        with self.doc.create(po[info['pos']]) as el:
            el.append(NoEscape(r'\pageref{LastPage}'))

    def make_new_page(self):
        self.doc.append(NewPage())

    def skip_numbering(self):
        self.doc.append(NoEscape(r'\thispagestyle{empty}'))

# ВНЕШКА
    def gen_tex(self, user_id):
        us_tex_path = f"../users/{user_id}/finish_files/tex_files/"
        self.doc.generate_tex(us_tex_path + f'{user_id}')
        # self.doc.generate_pdf(us_tex_path + f'{user_id}', clean_tex=False)
        # self.doc.generate_tex(f'{user_id}')
        # self.doc.generate_pdf(f'{user_id}', clean_tex=False)

    # def gen_pdf(self, user_id):
    #     us_tex_path = f"../users/{user_id}/finish_files/tex_files/{user_id}.tex"
    #     self.doc = Document(us_tex_path)
    #     us_pdf_path = f"../users/{user_id}/finish_files/pdf_files/{user_id}"
    #     self.doc.generate_pdf(us_pdf_path, clean_tex=False)
