from doc_class import LatexDocument

users_data = {
}