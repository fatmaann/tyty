import json


func_dict = {
    'numeration_style': "make_numeration_style",
    'center_page_title': 'center_page_title',
    'title': 'make_title',
    'subtitle': 'make_subtitle',
    'subsubtitle': 'make_subsubtitle',
    'paragraph': 'add_paragraph',
    'subparagraph': 'add_subparagraph',
    'table': 'make_table',
    'numeration': 'make_numeration_style',
    'text': 'add_text',
    'image': 'add_image',
    'number_of_pages': 'add_number_of_pages',
    'new_page': 'make_new_page',
    'skip_numbering': 'skip_numbering'
}


def fill_the_doc(user_id, data):
    doc = data[user_id]
    with open(f'../users/{user_id}/json_files/{user_id}.json', "r",
              encoding='utf-8') as file:
        our_doc = json.load(file)
    for key, val in our_doc.items():
        func = func_dict[key.split()[0]]
        print(func)
        if not val:
            eval(f'doc.{func}()')
        else:
            eval(f'doc.{func}({val})')
    doc.gen_tex(user_id)
