bot_info = {
    "name": "bot_name",
    "token": "5809287854:AAGR8_1nKa-EAQYaUhML1tg5Xv1EEOKRqkg"
}
