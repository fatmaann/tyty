from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, \
    ReplyKeyboardRemove, InlineKeyboardMarkup, InlineKeyboardButton
from configure import bot_info

bot = Bot(bot_info["token"])
dp = Dispatcher(bot)
ugly_sticker_id = "CAACAgIAAxkBAAEHirNj2l72haw3OFpaChluxIykPie5DwACkyYAArgPYEvYvJl2EM7UJC4E"
pic_id = "https://steamuserimages-a.akamaihd.net/ugc/1834667908926764360/FEA607F330C0DFE0600CB45B97FCA159E58C4456/?imw=512&imh=384&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=true"

kb = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
b1 = KeyboardButton('/help')
b2 = KeyboardButton('/help')
kb.add(b1)
kb.add(b2)

in_kb = InlineKeyboardMarkup(row_width=2)
in1 = InlineKeyboardButton(text='1', callback_data='/')
in2 = InlineKeyboardButton(text='2', callback_data='/')
in_kb.add(in1, in2)


async def on_startup(_):
    print("Бот успешно запущен")


@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await message.answer("<em> <b>добро</b> пожаловать</em>",
                         parse_mode="HTML", reply_markup=kb)
    # await message.delete()


@dp.message_handler(commands=['inline'])
async def inline_command(message: types.Message):
    await bot.send_message(chat_id=message.from_user.id,
                           text="Проверка инлайн кнопок",
                           reply_markup=in_kb)


@dp.message_handler(commands=['help'])
async def help_command(message: types.Message):
    await message.reply(text="я вам помогу)",
                        reply_markup=ReplyKeyboardRemove())


@dp.message_handler()
async def send_emoji(message: types.Message):
    await message.answer(message.text + '😞')


if __name__ == '__main__':
    executor.start_polling(dp, on_startup=on_startup, skip_updates=True)
