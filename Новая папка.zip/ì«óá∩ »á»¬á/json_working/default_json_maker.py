import json

js_doc = {
    "doc_style": {
        "font_size": 12,
        "geom_options": {"tmargin": "20mm", "lmargin": "30mm",
                         "bmargin": "20mm", "rmargin": "10mm"},
        # "numeration": {"num_place": "H",
        #                "pos": "C",
        #                "num_type": r'\thepage\\'
        #                }
    },
    "doc_data": {
        "center_page_title": {"text": "default center_page_title text",
                              "numbering": True,
                              "pos": "C"},
        "title": {"text": "default title text",
                  "numbering": True,
                  "pos": "C"},
        "subtitle": {"text": "default subtitle text",
                     "numbering": True,
                     "pos": "L"},
        "subsubtitle": {"text": "default subsubtitle text",
                        "numbering": True,
                        "pos": "L"},
        "paragraph": {"text": "default paragraph text",
                      "numbering": True,
                      "pos": "L"},
        "subparagraph": {"text": "default subparagraph text",
                         "numbering": True,
                         "pos": "C"},
        "image": {"pic_name": "default_name.png title text"},
        "number_of_pages": {"pos": "C"},
        "new_page": {"num": 1},
        "skip_numbering": {},
    }
}

with open('../users/default_user/json_files/default.json', 'w') as file:
    data = json.dumps(js_doc)
    data = json.loads(str(data))
    json.dump(data, file, indent=4)
