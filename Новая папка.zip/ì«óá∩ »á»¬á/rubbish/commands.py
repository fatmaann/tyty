from pylatex import Document, Section, Subsection,\
    Command, Package, Head, Center, Foot, NewPage
from pylatex.utils import italic, NoEscape, rm_temp_dir
from pylatex.basic import NewLine
from pylatex.headfoot import PageStyle, simple_page_number


def add_title(text):
    pass


s = {
    'Титульник': {
        'дата': 0,
        'заголовок': 'текст'
    },
    'Cодержание': {
        'Заголовок': 'название содеражания',
        'Страницы': []
    }
}

com = {'дата': add_title}

com['дата']('asdasdsad')
doc = Document('doc_1', )

# Просто текст
doc.append('Some text')

# Кириллический тест
doc.packages.add(Package('babel', options=['english', 'russian']))

# Верхний колонтитул
head_of_page = PageStyle('header', header_thickness=0.5, footer_thickness=1.0)
with head_of_page.create(Head('C')):  # R/L - будет справа/слева
    head_of_page.append('Глава 1')
    doc.preamble.append(head_of_page)
    doc.change_document_style('header')


# Поля
## До создания переменной doc
margins = {'top_m': '20mm', 'bot_m': '20mm', 'left_m': '25mm', 'right_m': '25mm'}
doc_m = Document('basic', geometry_options=margins)

# Заголовок
with doc.create(Center()) as center:
    with center.create(Section(title='Заголовок 1', numbering=False)) as sec:
        sec.numbering=True

# Подзаголовок
with doc.create(Subsection('Подзаголовок 1')) as subs:
    subs.numbering = False
    subs.append('Текст подзаголовка')


# Красная строка
doc.preamble.append(NoEscape(r'\setlength{\parident}{5ex}'))

# Отступ между абзацами
doc.preamble.append(NoEscape(r'\setlength{\parskip}{1ex}'))

# Перенос на новый абзац
doc.append(NoEscape(r'\par'))

# Нумерация страниц
with head_of_page.create(Foot('C')) as foot_numb:
    foot_numb.append('номер страницы')

# Целые слова на строчках
doc.append((NoEscape(r'\pretolerance=10000')))

# Шрифт текста для всего дока
doc.append((NoEscape(r'\fontsize{12}{12pt}\selectfont')))

# Шрифт текста для названия абзаца
# with doc.create(Subsection(NoEscape(r'\fontsize{14}{14pt}\selectfont{Подзаголовок 1}'))) as subs:

# Новая страница
doc.append(NewPage())
