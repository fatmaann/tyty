from pylatex import Document, Figure, MiniPage, Tabularx, MultiColumn, TextColor
from pylatex.section import Section, Subsection, \
    Paragraph, Subsubsection, Subparagraph
from pylatex.utils import NoEscape, rm_temp_dir, bold
from pylatex.basic import NewLine, NewPage, Package, LargeText, \
    LineBreak, MediumText
from pylatex.headfoot import PageStyle, simple_page_number, Foot, Head, Command
from pylatex.position import VerticalSpace, FlushLeft, FlushRight, Center

geom_options = {"tmargin": "20mm", "lmargin": "30mm",
                "bmargin": "20mm", "rmargin": "10mm"}
pos = {'R': FlushRight(), 'L': FlushLeft(), 'C': Center()}
doc = Document('doc_1', geometry_options=geom_options)
doc.documentclass = Command('documentclass',
                            options=[f'12pt'],
                            arguments=['article'])
doc.packages.add(Package('babel', options=['english', 'russian']))
doc.packages.add(Package('fancyhdr'))
doc.packages.add(Package('tocvsec2'))
doc.packages.append(Package("graphicx"))
doc.packages.append(Package("parskip"))
# doc.append(NoEscape(r'\settocdepth{subparagraph}'))


with doc.create(Center()) as el:
    el.append('Привет')

with doc.create(Center()) as el:
    el.append(Section("Программы", numbering=True))

doc.append("agfeiuowsgfuibfiesubfisebfieusbfsebfbseiufbisebfiusefb")

with doc.create(Center()) as el:
    el.append(Section("Программы 2", numbering=True))

doc.append("agfeiuowsgfuibfiesubfisebfieusbfsebfbseiufbisebfiusefb")

doc.generate_tex('test_tex')
